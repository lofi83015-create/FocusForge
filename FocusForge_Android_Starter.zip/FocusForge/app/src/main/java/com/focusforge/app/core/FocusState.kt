package com.focusforge.app.core

import android.content.Context

object FocusState {
    private const val PREFS = "focus_state"
    fun start(context: Context, minutes: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putBoolean("active", true)
            .putLong("end_at", System.currentTimeMillis() + minutes.coerceIn(1, 240) * 60_000L)
            .apply()
    }
    fun stop(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putBoolean("active", false).remove("end_at").apply()
    }
    fun isActive(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val active = prefs.getBoolean("active", false)
        if (active && prefs.getLong("end_at", 0L) <= System.currentTimeMillis()) { stop(context); return false }
        return active
    }
    fun remainingMillis(context: Context): Long = (context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("end_at", 0L) - System.currentTimeMillis()).coerceAtLeast(0L)
}

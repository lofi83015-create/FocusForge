package com.focusforge.app

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import com.focusforge.app.core.FocusState
import com.focusforge.app.data.AppDatabase
import kotlinx.coroutines.*

/** Observes package transitions only; does not read view text or transmit activity data. */
class DistractionAccessibilityService : AccessibilityService() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var lastPackage: String? = null
    private var lastLaunch = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (!FocusState.isActive(this)) { lastPackage = null; return }
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName || pkg == "com.android.systemui" || pkg == lastPackage) return
        lastPackage = pkg
        serviceScope.launch {
            val isBlocked = AppDatabase.get(applicationContext).blockedAppDao().enabledPackages().contains(pkg)
            val now = System.currentTimeMillis()
            if (isBlocked && now - lastLaunch > 1500L) {
                lastLaunch = now
                val intent = Intent(applicationContext, BlockScreenActivity::class.java).apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                    putExtra("package_name", pkg)
                }
                startActivity(intent)
            }
        }
    }
    override fun onInterrupt() = Unit
    override fun onDestroy() { serviceScope.cancel(); super.onDestroy() }
}

package com.focusforge.app

import android.app.AppOpsManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.focusforge.app.core.FocusState
import com.focusforge.app.data.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) { FocusForgeApp(AppDatabase.get(this)) } }
    }
}

private enum class Screen(val title: String) { Home("Home"), Focus("Focus"), Planner("Planner"), Distractions("Block apps"), Insights("Insights"), Settings("Settings") }

@OptIn(ExperimentalMaterial3Api::class)
@Composable private fun FocusForgeApp(db: AppDatabase) {
    var screen by remember { mutableStateOf(Screen.Home) }
    Scaffold(
        topBar = { TopAppBar(title = { Text("FocusForge", fontWeight = FontWeight.Bold) }, actions = { IconButton(onClick = { screen = Screen.Settings }) { Icon(Icons.Default.Settings, "Settings") } }) },
        bottomBar = { NavigationBar { listOf(Screen.Home, Screen.Focus, Screen.Planner, Screen.Distractions, Screen.Insights).forEach { s ->
            NavigationBarItem(selected = screen == s, onClick = { screen = s }, icon = { Icon(when (s) { Screen.Home -> Icons.Default.Home; Screen.Focus -> Icons.Default.PlayArrow; Screen.Planner -> Icons.Default.MenuBook; Screen.Distractions -> Icons.Default.Lock; else -> Icons.Default.Analytics }, s.title) }, label = { Text(s.title) })
        } } }
    ) { pad -> when (screen) {
        Screen.Home -> HomeScreen(db, Modifier.padding(pad), { screen = Screen.Focus }, { screen = Screen.Distractions })
        Screen.Focus -> FocusScreen(db, Modifier.padding(pad))
        Screen.Planner -> PlannerScreen(db, Modifier.padding(pad))
        Screen.Distractions -> DistractionsScreen(db, Modifier.padding(pad))
        Screen.Insights -> InsightsScreen(Modifier.padding(pad))
        Screen.Settings -> SettingsScreen(Modifier.padding(pad))
    } }
}

@Composable private fun HomeScreen(db: AppDatabase, modifier: Modifier, onFocus: () -> Unit, onBlock: () -> Unit) {
    val sessions by db.focusDao().sessions().collectAsStateWithLifecycle(initialValue = emptyList())
    val tasks by db.taskDao().tasks().collectAsStateWithLifecycle(initialValue = emptyList())
    LazyColumn(modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item { Text("Make time for what matters.", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Text("Focus, study, and digital wellbeing in one place.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        item { Card(shape = RoundedCornerShape(24.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.fillMaxWidth().padding(20.dp)) { Text("FOCUS MODE", style = MaterialTheme.typography.labelLarge); Spacer(Modifier.height(6.dp)); Text("Protect your attention", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Text("Selected distracting apps are interrupted while a focus session is active."); Spacer(Modifier.height(12.dp)); Button(onClick = onFocus) { Icon(Icons.Default.PlayArrow, null); Spacer(Modifier.width(8.dp)); Text("Start focusing") } }
        } }
        item { Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) { MetricCard("Sessions", "${sessions.size}", Modifier.weight(1f)); MetricCard("Tasks left", "${tasks.count { !it.completed }}", Modifier.weight(1f)) } }
        item { Card(onClick = onBlock, modifier = Modifier.fillMaxWidth()) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Default.Lock, null); Spacer(Modifier.width(12.dp)); Column { Text("Distraction protection", fontWeight = FontWeight.SemiBold); Text("Choose apps to interrupt during focus time", style = MaterialTheme.typography.bodySmall) } } } }
        item { Text("Next tasks", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        if (tasks.none { !it.completed }) item { Text("No open tasks. Add a study task in Planner.", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(tasks.filter { !it.completed }.take(4), key = { it.id }) { ListItem(headlineContent = { Text(it.title) }, supportingContent = { Text(it.subject) }, leadingContent = { Icon(Icons.Default.MenuBook, null) }) }
    }
}

@Composable private fun MetricCard(title: String, value: String, modifier: Modifier = Modifier) { Card(modifier) { Column(Modifier.padding(16.dp)) { Text(title, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(value, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) } } }

@Composable private fun FocusScreen(db: AppDatabase, modifier: Modifier) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var minutes by remember { mutableIntStateOf(25) }
    var active by remember { mutableStateOf(FocusState.isActive(ctx)) }
    var remaining by remember { mutableLongStateOf(FocusState.remainingMillis(ctx)) }
    LaunchedEffect(active) { while (active) { active = FocusState.isActive(ctx); remaining = FocusState.remainingMillis(ctx); delay(1000) } }
    val clock = "%02d:%02d".format(TimeUnit.MILLISECONDS.toMinutes(remaining), TimeUnit.MILLISECONDS.toSeconds(remaining) % 60)
    Column(modifier.fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(if (active) "Focus session active" else "Ready to focus?", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp)); Text(if (active) clock else "%02d:00".format(minutes), style = MaterialTheme.typography.displayLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.height(20.dp))
        if (!active) {
            Text("Duration: $minutes minutes"); Slider(value = minutes.toFloat(), onValueChange = { minutes = it.toInt().coerceIn(5, 120) }, valueRange = 5f..120f, steps = 22)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { listOf(15,25,45,60).forEach { n -> FilterChip(selected = minutes == n, onClick = { minutes = n }, label = { Text("$n min") }) } }
            Spacer(Modifier.height(18.dp)); Button(onClick = { FocusState.start(ctx, minutes); scope.launch { db.focusDao().addSession(FocusSession(startedAt = System.currentTimeMillis(), plannedMinutes = minutes)) }; active = true }, modifier = Modifier.fillMaxWidth()) { Text("Start focus session") }
        } else { Text("Apps in your blocklist will be interrupted if blocking permission is enabled."); Spacer(Modifier.height(18.dp)); Button(onClick = { FocusState.stop(ctx); active = false }, modifier = Modifier.fillMaxWidth()) { Text("End session") } }
    }
}

@Composable private fun PlannerScreen(db: AppDatabase, modifier: Modifier) {
    val tasks by db.taskDao().tasks().collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope(); var title by remember { mutableStateOf("") }; var subject by remember { mutableStateOf("Study") }
    Column(modifier.fillMaxSize().padding(18.dp)) {
        Text("Study planner", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp))
        OutlinedTextField(title, { title = it }, label = { Text("Task or study goal") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(8.dp)); OutlinedTextField(subject, { subject = it }, label = { Text("Subject") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(8.dp)); Button(onClick = { if (title.isNotBlank()) { scope.launch { db.taskDao().add(StudyTask(title = title.trim(), subject = subject.ifBlank { "General" })) }; title = "" } }, modifier = Modifier.fillMaxWidth()) { Text("Add task") }
        Spacer(Modifier.height(16.dp)); Text("Your tasks", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        LazyColumn { items(tasks, key = { it.id }) { task -> Card(Modifier.fillMaxWidth().padding(vertical = 4.dp)) { Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) { Checkbox(task.completed, { checked -> scope.launch { db.taskDao().update(task.copy(completed = checked)) } }); Column { Text(task.title, fontWeight = FontWeight.SemiBold); Text(task.subject, style = MaterialTheme.typography.bodySmall) } } } } }
    }
}

@Composable private fun DistractionsScreen(db: AppDatabase, modifier: Modifier) {
    val context = LocalContext.current
    val blocked by db.blockedAppDao().all().collectAsStateWithLifecycle(initialValue = emptyList())
    val pm = context.packageManager
    val apps = remember { @Suppress("DEPRECATION") pm.getInstalledApplications(0).filter { pm.getLaunchIntentForPackage(it.packageName) != null && it.packageName != context.packageName }.map { it.packageName to pm.getApplicationLabel(it).toString() }.sortedBy { it.second.lowercase() } }
    val selected = blocked.map { it.packageName }.toSet(); val scope = rememberCoroutineScope()
    Column(modifier.fillMaxSize().padding(16.dp)) {
        Text("Apps to pause", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("When a focus session is active, opening a selected app brings up a reminder screen. Enable Accessibility Blocking in Settings first.", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(8.dp)); OutlinedButton(onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Enable Accessibility Blocking") }
        LazyColumn { items(apps, key = { it.first }) { (pkg, label) -> Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) { Checkbox(pkg in selected, { checked -> scope.launch { if (checked) db.blockedAppDao().upsert(BlockedApp(pkg, label)) else db.blockedAppDao().remove(pkg) } }); Column { Text(label); Text(pkg, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) } }; HorizontalDivider() } }
    }
}

@Composable private fun InsightsScreen(modifier: Modifier) {
    val context = LocalContext.current; val access = remember { hasUsageAccess(context) }
    Column(modifier.fillMaxSize().padding(20.dp)) { Text("Insights", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.height(10.dp)); Text("Android requires Usage Access before an app can read app-usage statistics. This starter shows permission status; detailed charts are a next implementation milestone."); Spacer(Modifier.height(16.dp)); ListItem(headlineContent = { Text("Usage Access") }, supportingContent = { Text(if (access) "Permission appears granted" else "Permission required") }, leadingContent = { Icon(Icons.Default.Analytics, null) }); Button(onClick = { context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Open Usage Access settings") } }
}

@Composable private fun SettingsScreen(modifier: Modifier) {
    val context = LocalContext.current
    Column(modifier.fillMaxSize().padding(20.dp)) { Text("Settings & permissions", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold); Spacer(Modifier.height(12.dp)); Text("Usage Access enables app-usage statistics."); Button(onClick = { context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Grant Usage Access") }; Spacer(Modifier.height(8.dp)); Text("Accessibility Blocking detects selected foreground apps during active focus sessions."); Button(onClick = { context.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }, modifier = Modifier.fillMaxWidth()) { Text("Enable Accessibility Blocking") }; Spacer(Modifier.height(18.dp)); Text("Privacy", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold); Text("The service compares the foreground package name against your blocklist. It does not read screen text or send activity data to a server.") }
}

private fun hasUsageAccess(context: Context): Boolean {
    val ops = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
    @Suppress("DEPRECATION") val mode = ops.checkOpNoThrow("android:get_usage_stats", android.os.Process.myUid(), context.packageName)
    return mode == AppOpsManager.MODE_ALLOWED
}

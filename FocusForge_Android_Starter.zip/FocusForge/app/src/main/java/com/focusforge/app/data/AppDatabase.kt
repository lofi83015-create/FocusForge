package com.focusforge.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FocusDao {
    @Query("SELECT * FROM focus_sessions ORDER BY startedAt DESC") fun sessions(): Flow<List<FocusSession>>
    @Insert suspend fun addSession(session: FocusSession): Long
    @Query("UPDATE focus_sessions SET endedAt = :endedAt, completed = :completed WHERE id = :id") suspend fun finishSession(id: Long, endedAt: Long, completed: Boolean)
}

@Dao
interface TaskDao {
    @Query("SELECT * FROM study_tasks ORDER BY completed ASC, createdAt DESC") fun tasks(): Flow<List<StudyTask>>
    @Insert suspend fun add(task: StudyTask): Long
    @Update suspend fun update(task: StudyTask)
}

@Dao
interface BlockedAppDao {
    @Query("SELECT * FROM blocked_apps ORDER BY appLabel COLLATE NOCASE") fun all(): Flow<List<BlockedApp>>
    @Query("SELECT packageName FROM blocked_apps WHERE enabled = 1") suspend fun enabledPackages(): List<String>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsert(app: BlockedApp)
    @Query("DELETE FROM blocked_apps WHERE packageName = :packageName") suspend fun remove(packageName: String)
}

@Database(entities = [FocusSession::class, StudyTask::class, BlockedApp::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun focusDao(): FocusDao
    abstract fun taskDao(): TaskDao
    abstract fun blockedAppDao(): BlockedAppDao
    companion object {
        @Volatile private var instance: AppDatabase? = null
        fun get(context: Context): AppDatabase = instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "focusforge.db").build().also { instance = it }
        }
    }
}

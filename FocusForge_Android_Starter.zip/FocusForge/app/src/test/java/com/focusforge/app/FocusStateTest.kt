package com.focusforge.app

import org.junit.Assert.assertEquals
import org.junit.Test

class FocusStateTest {
    @Test fun expiredTimeClampsToZero() { assertEquals(0L, (1_000L - 2_000L).coerceAtLeast(0L)) }
    @Test fun twentyFiveMinutesInMillis() { assertEquals(1_500_000L, 25 * 60_000L) }
}

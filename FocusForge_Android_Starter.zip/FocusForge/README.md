# FocusForge — Android productivity starter

A native Android starter for focus sessions, study tasks, and user-configured distraction interruption.

## What works in this starter
- Kotlin + Jetpack Compose + Material 3 UI
- Room persistence for focus sessions, study tasks, and selected apps
- Focus timer with presets and persisted end time
- Add/complete study tasks
- Select installed launchable apps for the distraction list
- Accessibility-service integration that detects a selected foreground app during an active focus session and launches an interruption screen
- Links to Android Usage Access and Accessibility settings
- GitHub Actions workflow to build a debug APK in the cloud

## Important limitation
Android does not provide a universal, tamper-proof API for ordinary apps to prevent another app from launching. This project uses an opt-in AccessibilityService to observe foreground package transitions and open a reminder activity. It does not read screen content or transmit activity data. Device/OEM behavior varies; the target app may briefly appear and some devices may restrict background activity launches. This is not a guaranteed hard lock. Accessibility usage must be disclosed and reviewed against Google Play policy before publication.

The starter's Insights screen is a permission-status placeholder, not a completed usage analytics dashboard. Cloud sync, login, scheduled rules, habits, calendar planning, export, notification scheduling, and release signing are not yet implemented.

## Build locally
Open in Android Studio with JDK 17 and Android SDK 35, sync Gradle, then run the app. If you have Gradle installed, run `gradle assembleDebug`. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

## Build using only a phone (cloud build)
1. Create a GitHub account if needed and create a new repository named `FocusForge`.
2. In your phone browser, open the repository and use **Add file → Upload files** to upload the contents of this project ZIP (extract it first if GitHub's upload UI does not accept the ZIP as source files). Keep `.github/workflows/build-apk.yml` in the repository.
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab. Choose **Build Android APK** and tap **Run workflow**. If the workflow does not appear, check that `.github/workflows/build-apk.yml` is committed on `main`.
5. Wait for the workflow to finish successfully. Open that run, scroll to **Artifacts**, and download `FocusForge-debug-apk`.
6. Extract the downloaded artifact ZIP on your phone; it contains `app-debug.apk`. Tap it to install. Android may ask you to allow installation from that browser/file manager.

A debug APK is for testing, not Play Store publishing. For a release, configure signing securely and review permissions, privacy disclosures, and Google Play policies. Never commit a keystore or passwords to GitHub.

## Suggested next milestones
1. Verify blocking on your exact phone and Android version.
2. Implement actual UsageStatsManager daily/weekly charts and permission refresh.
3. Add scheduled focus rules, session recovery and notifications.
4. Add habits, streaks, subject statistics, CSV/JSON export, and data backup.
5. Add optional authentication/cloud sync only after privacy and security design.
